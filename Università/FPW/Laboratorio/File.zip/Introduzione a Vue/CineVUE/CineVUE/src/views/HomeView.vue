<script setup>
import TheWelcome from '../components/TheWelcome.vue'
</script>

<template>
  <main>
    <body>
        <Header/>
        <h2>Benvenuti su questo sito!</h2>
        <p>Su <b><a href="about">Cineva</a></b> potete scrivere recensioni su serie TV e condividere i vostri pensieri con la <u>community</u>.</p>
        
        <hr/>
        <h2>Recensioni in evidenza</h2>
        <h3>MommyDemi - "Anora"? No grazie</h3>
        <p>Ma davvero? Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        <p><b>Giudizio: 1/5 - Likes: 1.2k - Dislikes: 392</b></p>
    </body>
  </main>
</template>
