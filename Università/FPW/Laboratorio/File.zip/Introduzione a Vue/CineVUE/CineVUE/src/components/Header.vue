<script setup>
import Navbar from '../components/Navbar.vue'
</script>

<template>
    <a href="/"><img src="../assets/png/logo.png" alt="Logo di Cineva" width="200"></a>
      <h1>Cineva</h1>
    <Navbar/>
</template>